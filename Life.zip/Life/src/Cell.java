public final class Cell {
	boolean isLiving;
	int colour;
	Cell(boolean isLiving) {
		this.isLiving = isLiving;
		colour = 0;
	}
}